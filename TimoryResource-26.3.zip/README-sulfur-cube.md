# 硫方怪物品模型

适用于本资源包当前的 Java 版 Minecraft 26.3。命名空间为 `timorymedal`，共四个独立模型；仅提供资源，不注册物品、不修改 Mod 或数据包。

| 外观 | `minecraft:item_model` |
| --- | --- |
| 内含金块 | `timorymedal:sulfur_cube_gold` |
| 内含铁块 | `timorymedal:sulfur_cube_iron` |
| 内含铜块 | `timorymedal:sulfur_cube_copper` |
| 无包含物 | `timorymedal:sulfur_cube_empty` |

`assets/timorymedal/items/` 为物品模型入口，`assets/timorymedal/models/item/` 为三维模型，`assets/timorymedal/textures/block/` 为硫方怪本体贴图。

模型使用原版成年硫方怪的 18:16 外壳 / 内部比例、原版 UV 和本体贴图。金、铁、铜版的内部引用对应原版方块贴图；空版保留硫方怪本身的内部组织。外壳使用 26.3 的 `force_translucent` 材质设置。四个模型均配置背包、手持、掉落、物品展示框及头部显示变换。

如需在游戏中预览，可将资源包加载后执行以下命令。这些命令只是给原版纸张指定外观，不会注册新物品：

```mcfunction
/give @s minecraft:paper[minecraft:item_model="timorymedal:sulfur_cube_gold"]
/give @s minecraft:paper[minecraft:item_model="timorymedal:sulfur_cube_iron"]
/give @s minecraft:paper[minecraft:item_model="timorymedal:sulfur_cube_copper"]
/give @s minecraft:paper[minecraft:item_model="timorymedal:sulfur_cube_empty"]
```
