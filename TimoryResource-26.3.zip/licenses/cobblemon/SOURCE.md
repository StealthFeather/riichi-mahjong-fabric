# Cobblemon Poke Ball assets

Source: https://github.com/Cobblemon-Global/Cobblemon

Revision: `75bb1a6c2fe92ef54951fb68d16d21f290a9ee88`

Upstream project: https://gitlab.com/cable-mc/cobblemon

The accompanying LICENSE is the source repository's Mozilla Public License 2.0.
Original files by the Cobblemon contributors:

- `common/src/main/resources/assets/cobblemon/models/item/poke_ball_model.json`
- `common/src/main/resources/assets/cobblemon/textures/item/poke_balls/models/poke_ball.png` (model.png)
- `common/src/main/resources/assets/cobblemon/textures/item/poke_balls/poke_ball.png` (icon.png)

Timory adapts model coordinates to the vanilla Java item origin, changes texture identifiers,
and supplies vanilla display transforms. Geometry and original textures are retained.
`scripts/import-cobblemon-pokeball.cjs` generates the adapted model reproducibly.
No Cobblemon code or client mod is required. The original model and this notice are
included in the resource pack under `licenses/cobblemon/` (the source model is `poke_ball_model.json.txt`).
