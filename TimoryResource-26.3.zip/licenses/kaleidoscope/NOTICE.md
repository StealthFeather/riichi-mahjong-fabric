# Kaleidoscope integration

Official content baseline: Kaleidoscope Cookery 1.6.0 and Kaleidoscope Tavern 1.2.0, by the Kaleidoscope Official Production Team (ysbb, tartaric_acid and contributors). Official code is BSD-3-Clause; official models, textures, sounds and other assets are CC-BY-NC-SA-4.0. The complete original notices are in the respective module directories.

Minecraft 26.3 compatibility uses NightEpiphany's Fabric ports, Cookery 1.6.0.7 and Tavern 1.2.0.13, with credits to the upstream teams and Dobelring. Their declared licenses are BSD-3-Clause for code and CC-BY-NC-SA-4.0 for assets. Exact download URLs and cryptographic hashes are recorded in `upstream-lock.json`.

Sources:

- https://github.com/KaleidoscopeMods/KaleidoscopeCookery
- https://github.com/KaleidoscopeMods/KaleidoscopeTavern
- https://github.com/NightEpiphany/KaleidoscopeCookery
- https://github.com/NightEpiphany/KaleidoscopeTavern-Refabricated

Polymer 0.18.7+26.3 by Patbox and contributors is included without code changes as a nested JAR under LGPL-3.0. Source for this version is available at https://github.com/Patbox/polymer/tree/35a601d12e5084d5f953c3961bdba59a53e69a10 . Its license is included alongside this notice. Polymer can be replaced by updating its nested JAR and the corresponding Fabric metadata dependency entries; no client Mod is required.

Timory modifications convert model conditions, Java model cubes and animations to vanilla resources and display entities; add server protocol overlays, menus, migration and legacy recipes; filter content to the selected official releases; restore the official tea timing and fix the port's Bloody Mary death cancellation. User-selected adaptations remove Grass Stealth entirely and replace worn string-light geometry with armor textures. The other agreed display adaptations are documented in README-kaleidoscope.md. Original asset SHA-256 hashes, before conversion, are recorded in `asset-manifest.json`. Converted assets retain the CC-BY-NC-SA-4.0 license and attribution.

Timory also restores complete scarecrow shoulder-parrot persistence and release from the official implementation, including identity, variant and custom entity data. Official view-specific item models are converted to vanilla display-context selectors.
The official farmer-outfit swimming bonus is also restored for non-player living entities; the port had limited it to players.
Entity-model UVs outside the first texture tile are preserved through repeated padding textures for the vanilla atlas baker; obsolete chain texture references are updated to iron_chain.

Timory 2.7.1 removes physical collision proxy blocks, corrects the shared display attachment origin, and groups fixed multi-block displays under one primary holder while preserving upstream occupied positions and storage. Collisionless virtual interaction areas route right-clicks and user-selected immediate left-click removal through server block rules, including survival drops and permission checks.

Timory 2.7.2 groups all 27 occupied barrel positions under the bottom-center visual owner, avoiding duplicated complete barrels and simultaneous open/closed lids. Each occupied block now uses exactly one approximate collisionless interaction area instead of subdivided model hit areas; original use routing and immediate survival removal remain.

Timory 2.7.3 renders fixed rigid structures and both complete barrel lid states as single vanilla composite item displays. One interaction covers each entire fixed structure and routes clicks to original occupied positions. The tabletop uses one continuous original texture surface. ModelPart minY/maxY UV strip mapping is corrected and checked against unmodified client ModelPart cubes. Independently animated millstone pieces and variable inventory contents retain necessary displays.
