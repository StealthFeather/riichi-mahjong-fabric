const fs=require('node:fs'),p=require('node:path'),crypto=require('node:crypto'),{execFileSync:exec}=require('node:child_process');
const {project,root,build,copyTree,javaTool,version,jarName:jar,jarPath,release,baselinePack,resourceRoot,changelog}=require('./build-config.cjs');
const pack=p.join(build,'merged-pack'),sources=p.join(build,'release-sources');
const fileList=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?fileList(p.join(d,e.name)):[p.join(d,e.name)]);
const hash=(file,alg='sha256')=>crypto.createHash(alg).update(fs.readFileSync(file)).digest('hex');
const verification=JSON.parse(fs.readFileSync(p.join(build,'verification.json'),'utf8'));
if(!verification.passed||verification.version!==version||verification.jarSha256!==hash(jarPath))throw Error('Build and run node test.cjs before packaging this version.');
for(const required of [baselinePack,changelog])if(!fs.existsSync(required))throw Error('Missing package input: '+required+'; see BUILDING.md');
fs.mkdirSync(release,{recursive:true});fs.rmSync(pack,{recursive:true,force:true});fs.mkdirSync(pack,{recursive:true});
exec(javaTool('jar'),['--extract','--file',baselinePack],{cwd:pack,windowsHide:true});
// The baseline supplies all other gameplay assets; only the original Mahjong namespace is added.
// Package exactly the assets compiled into this mod, including local overrides.
copyTree(p.join(project,'src/main/resources/assets/riichi_mahjong'),p.join(pack,'assets/riichi_mahjong'));
const configuredAtlasRoot=p.join(resourceRoot,'assets/minecraft/atlases');
const atlasRoot=fs.existsSync(configuredAtlasRoot)?configuredAtlasRoot:p.join(project,'upstream/neoforge/src/main/resources/assets/minecraft/atlases');
for(const file of fs.readdirSync(atlasRoot)){
 const dest=p.join(pack,'assets/minecraft/atlases',file),source=JSON.parse(fs.readFileSync(p.join(atlasRoot,file)));
 const current=fs.existsSync(dest)?JSON.parse(fs.readFileSync(dest)):{sources:[]};
 current.sources=[...new Map([...(current.sources||[]),...(source.sources||[])].map(x=>[JSON.stringify(x),x])).values()];
 fs.mkdirSync(p.dirname(dest),{recursive:true});fs.writeFileSync(dest,JSON.stringify(current));
}
if(fs.existsSync(p.join(resourceRoot,'pack.mcmeta')))fs.copyFileSync(p.join(resourceRoot,'pack.mcmeta'),p.join(pack,'pack.mcmeta'));
if(!fs.existsSync(p.join(pack,'pack.mcmeta')))throw Error('The baseline resource pack must contain pack.mcmeta.');
for(const file of ['LICENSE.txt'])fs.copyFileSync(p.join(project,'upstream',file),p.join(release,file));
fs.copyFileSync(p.join(project,'upstream/neoforge/src/main/resources/LICENSE_mahjong4j.txt'),p.join(release,'LICENSE_mahjong4j.txt'));
for(const name of ['majiang-ai','majiang-core'])fs.copyFileSync(p.join(project,'ai/node_modules/@kobalab',name,'LICENSE'),p.join(release,'LICENSE_'+name+'.txt'));
fs.copyFileSync(p.join(project,'PORTING.md'),p.join(release,'README.md'));
fs.copyFileSync(changelog,p.join(release,'CHANGES.md'));
fs.copyFileSync(p.join(build,'verification.json'),p.join(release,'verification.json'));
const databaseVerification=p.join(build,'replay-database-verification.json');
if(fs.existsSync(databaseVerification)){
 const databaseResult=JSON.parse(fs.readFileSync(databaseVerification,'utf8'));
 if(!databaseResult.passed||databaseResult.jarSha256!==hash(jarPath))throw Error('Database verification does not match this JAR.');
 fs.copyFileSync(databaseVerification,p.join(release,'replay-database-verification.json'));
}
fs.copyFileSync(jarPath,p.join(release,jar));
if(process.env.RIICHI_RESOURCE_PACK_BASELINE_IS_FINAL==='1'){
 // A published complete pack must retain its exact bytes and download hash.
 const assetRoot=p.join(project,'src/main/resources/assets/riichi_mahjong');
 // Check the published archive itself, independently of the overlay staging tree.
 const check=p.join(build,'published-pack-check');fs.rmSync(check,{recursive:true,force:true});fs.mkdirSync(check,{recursive:true});
 exec(javaTool('jar'),['--extract','--file',baselinePack],{cwd:check,windowsHide:true});
 for(const file of fileList(assetRoot)){
  const entry=p.join(check,'assets/riichi_mahjong',p.relative(assetRoot,file));
  if(!fs.existsSync(entry)||!fs.readFileSync(entry).equals(fs.readFileSync(file)))throw Error('Published pack does not match compiled assets: '+file);
 }
 fs.copyFileSync(baselinePack,p.join(release,'TimoryResource-26.3.zip'));
}else exec(javaTool('jar'),['--create','--no-manifest','--file',p.join(release,'TimoryResource-26.3.zip'),'-C',pack,'.'],{windowsHide:true});
if(p.relative(project,sources)!==p.join('build','release-sources'))throw Error('Unexpected source staging directory');
fs.rmSync(sources,{recursive:true,force:true});fs.mkdirSync(sources,{recursive:true});
for(const name of ['src','upstream','resource-overrides','build-config.cjs','prepare-local-deps.cjs','build.cjs','rules-patches.cjs','analysis-patches.cjs','sichuan-patches.cjs','joker-patches.cjs','exchange-patches.cjs','riichi-blood-patches.cjs','competition-patches.cjs','test.cjs','test-replay-database.cjs','resources.cjs','package.cjs','install-local.cjs','BUILDING.md','README.md','PORTING.md','prepare.cjs','adapt.cjs','docs','integration'])copyTree(p.join(project,name),p.join(sources,'riichi-mahjong-fabric',name));
const stagedAi=p.join(sources,'riichi-mahjong-fabric','ai');
for(const name of fs.readdirSync(p.join(project,'ai')).filter(name=>name!=='mortal'))
 copyTree(p.join(project,'ai',name),p.join(stagedAi,name));
for(const name of ['README.md','install.py','requirements.txt','smoke_test.py','worker','worker.py'])
 copyTree(p.join(project,'ai/mortal',name),p.join(stagedAi,'mortal',name));
exec(javaTool('jar'),['--create','--no-manifest','--file',p.join(release,'mortal-worker-'+version+'.zip'),'-C',stagedAi,'mortal'],{windowsHide:true});
fs.copyFileSync(p.join(project,'BUILDING.md'),p.join(sources,'BUILDING.md'));
fs.writeFileSync(p.join(sources,'README.md'),'# 立直麻将源码归档\n\n源码位于 riichi-mahjong-fabric/。请阅读 BUILDING.md 与 PORTING.md；JDK、Minecraft/Polymer 依赖和合并资源包基准需另行准备。\n');
exec(javaTool('jar'),['--create','--no-manifest','--file',p.join(release,'riichi-mahjong-fabric-sources.zip'),'-C',sources,'.'],{windowsHide:true});
const manifest={name:'Timory Mahjong',version,channel:version.includes('-')?'prerelease':'stable',upstream:'https://github.com/caxapexac/MinecraftRiichiMahjong',commit:'fe469836ed461d44998819dd3004c8dea01f5be0',minecraft:'26.3',loader:'Fabric',clientModRequired:false,resourcePack:'TimoryResource-26.3.zip',resourcePackSha1:hash(p.join(release,'TimoryResource-26.3.zip'),'sha1'),acceptance:'pending',checks:{compiled:true,packaged:true,gameplayTests:false,protocolTests:false,visualTests:false,rulesTests:true,humanControlTests:true,geometryTests:true},limitations:['原版客户端无法执行客户端 FOV 修改与渲染编辑器；交互采用显示实体、私有 interaction、ActionBar 与原版容器','原版流体使用水投影，客户端占位碰撞无法完全等同原 Mod','能源兼容需服务端具有 Team Reborn Energy API']};
manifest.baseRelease='0.5.5';
manifest.ai={...verification.ai,requires:'Node.js >=22 (Kobalab), Python 3.12 and local Mortal worker',runtimeBundled:false,networkServiceRequired:false};
manifest.checks.serverIntegrationTests=!!verification.serverIntegrationTest;
manifest.checks.clientMenuVisualTests=!!verification.clientVisualTest;
manifest.limitations.push('四麻电将 AI 需要服务端 Node.js 22+；三麻使用原 BOT；档位尚未大规模对战标定');
fs.writeFileSync(p.join(release,'release.json'),JSON.stringify(manifest,null,2)+'\n');
fs.writeFileSync(p.join(release,'SHA256SUMS.txt'),fileList(release).filter(f=>!f.endsWith('SHA256SUMS.txt')).map(f=>hash(f)+'  '+p.relative(release,f).replaceAll('\\','/')).join('\n')+'\n');
console.log(JSON.stringify({release,jar,packSha1:manifest.resourcePackSha1,packBytes:fs.statSync(p.join(release,'TimoryResource-26.3.zip')).size},null,2));
