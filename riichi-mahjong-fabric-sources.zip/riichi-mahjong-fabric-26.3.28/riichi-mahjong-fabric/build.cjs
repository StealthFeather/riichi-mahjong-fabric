const fs=require('node:fs'),p=require('node:path'),{execFileSync:exec}=require('node:child_process');
const {project,server,files,copyTree,javaTool,polymerJar,polymerClasspath,build,jarPath}=require('./build-config.cjs');
const classes=p.join(build,'classes'),rules=p.join(build,'rules');
for(const required of [javaTool('javac'),javaTool('jar'),p.join(server,'versions/26.3/server-26.3.jar'),polymerJar])if(!fs.existsSync(required))throw Error('Missing build dependency: '+required+'; see BUILDING.md');
fs.mkdirSync(build,{recursive:true});fs.mkdirSync(p.join(build,'libs'),{recursive:true});fs.rmSync(classes,{recursive:true,force:true});fs.mkdirSync(classes,{recursive:true});fs.mkdirSync(rules,{recursive:true});
const compile=(name,args)=>{const f=p.join(build,name+'.args');fs.writeFileSync(f,args.map(s=>'"'+s.replaceAll('\\','/')+'"').join('\n'));exec(javaTool('javac'),['-J-Duser.language=en','-J-Duser.country=US','@'+f],{stdio:'inherit',windowsHide:true});};
const ruleSources=files(p.join(project,'upstream/themahjong/src/main/java'),'.java');
const patches=require('./rules-patches.cjs');
for(const [relative,patch] of [['driver/TheMahjongDriver.java',patches],['TheMahjongRound.java',patches.round]]){
 const sourceIndex=ruleSources.findIndex(f=>f.endsWith(p.join('com','themahjong',relative)));
 if(sourceIndex<0)throw Error('Missing upstream rule source: '+relative);
 const patched=p.join(build,'rule-patches/com/themahjong',relative);
 fs.mkdirSync(p.dirname(patched),{recursive:true});
 fs.writeFileSync(patched,patch(fs.readFileSync(ruleSources[sourceIndex],'utf8').replaceAll('\r\n','\n')));
 ruleSources[sourceIndex]=patched;
}
ruleSources.push(...files(p.join(project,'src/rules/java'),'.java'));
compile('rules',['--release','25','-encoding','UTF-8','-proc:none','-d',rules,...ruleSources]);
const cp=[...new Set([rules,p.join(server,'versions/26.3/server-26.3.jar'),...files(p.join(server,'libraries'),'.jar'),...files(p.join(server,'.fabric/processedMods'),'.jar'),...polymerClasspath()])].join(p.delimiter);
compile('main',['--release','25','-encoding','UTF-8','-proc:none','-Xmaxerrs','200','-cp',cp,'-d',classes,...files(p.join(project,'src/main/java'),'.java')]);
copyTree(rules,classes);copyTree(p.join(project,'src/main/resources'),classes);
// Ship the pinned, offline AI sources; Node itself remains a server prerequisite.
const aiSource=p.join(project,'ai'),aiTarget=p.join(classes,'ai');
for(const name of ['worker.cjs','dependencies.json','node_modules']){
 if(!fs.existsSync(p.join(aiSource,name)))throw Error('Missing vendored AI runtime: '+name);
 copyTree(p.join(aiSource,name),p.join(aiTarget,name));
}
const aiFiles=files(aiTarget,'').map(file=>p.relative(aiTarget,file).replaceAll('\\','/')).sort();
fs.writeFileSync(p.join(aiTarget,'runtime-files.txt'),aiFiles.join('\n')+'\n');
fs.mkdirSync(p.join(classes,'META-INF/jars'),{recursive:true});fs.copyFileSync(polymerJar,p.join(classes,'META-INF/jars/polymer-bundled.jar'));
for(const file of ['LICENSE.txt'])fs.copyFileSync(p.join(project,'upstream',file),p.join(classes,file));
fs.copyFileSync(p.join(project,'upstream/neoforge/src/main/resources/LICENSE_mahjong4j.txt'),p.join(classes,'LICENSE_mahjong4j.txt'));
exec(javaTool('jar'),['--create','--file',jarPath,'-C',classes,'.'],{windowsHide:true});
fs.writeFileSync(p.join(build,'classpath.txt'),cp);console.log('Built '+jarPath+'. No tests run.');
